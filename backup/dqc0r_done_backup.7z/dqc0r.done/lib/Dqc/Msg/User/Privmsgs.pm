package Dqc::Msg::User::Privmsgs;
use 5.010;
use strict;
use warnings;
use utf8;
use Dqc;

our %Commands = (
    msg => sub {
        my $c = shift;
        my ($to, $msg) = split /\s+/, shift(), 2;
        die 'Aufruf: "/msg Benutzername Privatnachrichtentext"'
            unless $to and $msg;
        $to = substr $to, 0, 2048;
        my $u = $c->session()->{user};
        die 'Benutzernachrichten kann man nicht an sich selbst verschicken, klar!'
            if $to eq $u;
        Dqc::dbh()->do(
            'INSERT INTO prv_privatnachrichten 
            (prv_von, prv_an, prv_text, prv_zeit) 
            VALUES 
            ((SELECT ben_id FROM ben_benutzer WHERE ben_name=? LIMIT 1),(SELECT ben_id FROM ben_benutzer WHERE ben_name=? LIMIT 1),?,?)',
            undef, $u, $to, $msg, time );
        return qq'Privatnachricht an $to gesendet';
    },
);

1;

