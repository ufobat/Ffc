DQC - Online Web Quick Chat
===========================

!!! Die Software DQC wird nicht mehr eigenständig von mir weiter entwickelt, stattdessen wird diese Software in die Softwrae Ffc integriert !!!

Kleines Webchat-Mockup als Rewrite des Webchats von nem Kumpel, der seine Software leider aus Zeitgründen nicht mehr weiterpflegen kann und mir fehlte das Know-How, seine Entwicklung zu übernehmen. Außerdem sah ich hier das klassische Problem von NIH.

Features
--------

- Online-Webchat über eine Webseite (HTTP oder HTTPS)
- Geringes Bandbreitenaufkommen (es wird nur abgeholt, was wirklich gebraucht wird in dem Moment)
- Einstellung der Abholzeit auf Minutenbasis möglich (der Chat schaut nur aller soundsovieler Minuten nach neuen Nachrichten)
- Nachrichten abholen erfolgt auch im Hintergrund (oder minimiert)
- Die Anzahl neuer (Privat-)Nachrichten wird in der Titelleiste angezeigt, wenn das Browserfenster im Hintergrund (minimiert) ist
- Funktionen nur über Anmeldung zugänglich
- Benutzer müssen von Administator extra eingerichtet werden!
- Gruppenchat für mehrere Benutzer (eine handvoll ausgesuchte Teilnehmer)
- Privatnachrichten an einzelne Benutzer
- Kommandosyntax (mit führendem `/`) für Benutzer- und Administratorenoptionen
- Benutzerstatus
- Mehrzeilige Nachrichten über Strg+Enter oder Shift+Enter oder Alt+Enter
- Clearscreen-Button
- Detaillierte Informationen über angemeldete Benutzer mit Refreshzeit und wann das Chat-Browserfenster das letzte mal angeschaut wurde
- Mehrere optische Themen auswählbar
- Notizen als Merkzettel an einer Pinnwand für alle Benutzer
- Funktioniert in Firefox und div. Webkitbrowsern, IE macht natürlich Spacken, einer muss ja immer aus der Reihe tanzen
- Nachrichtenspeicher persistent in Datenbank
- XHTML/Javascript/CSS/AJAX - Frontend
- Mojolicious/Perl/SQL - Backend
- Umfangreiche Testsuite für das Backend
- URLs im Text werden automatisch durch Links ersetzt
- BBCodes werden im Rahmen unterstützt (`[b]...[/b]`, `[u]...[/u]`, `[i]...[/i]`)

Screenshots
-----------

![Screenshot des Styles Default](https://raw.github.com/Bierschnapswurst/dqc0r/master/public/themes/Default/Screenshot.png)
![Screenshot des Styles Dark](https://raw.github.com/Bierschnapswurst/dqc0r/master/public/themes/Dark/Screenshot.png)
![Screenshot des Styles Dqcisch](https://raw.github.com/Bierschnapswurst/dqc0r/master/public/themes/Dqcisch/Screenshot.png)
![Screenshot des Styles Retro95](https://raw.github.com/Bierschnapswurst/dqc0r/master/public/themes/Retro95/Screenshot.png)
![Screenshot des Styles Wiese](https://raw.github.com/Bierschnapswurst/dqc0r/master/public/themes/Wiese/Screenshot.png)
![Screenshot der Anzeige für mobile Geräte](https://raw.github.com/Bierschnapswurst/dqc0r/master/public/themes/Mobile/Screenshot.png)

