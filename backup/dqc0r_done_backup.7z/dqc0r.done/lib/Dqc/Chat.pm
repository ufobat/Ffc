package Dqc::Chat;
use Mojo::Base 'Mojolicious::Controller';

sub chatform {
    my $c = shift;
    $c->stash( otherusernames => [ map {$_->[0]} @{ Dqc::dbh()->selectall_arrayref(
        'SELECT ben_name FROM ben_benutzer WHERE ben_name<>? ORDER BY ben_lastseenfocus DESC, ben_name',
        undef, $c->session->{user}
    ) } ] );
    if ( $c->session->{mobile} ) {
        $c->render('chat/mobileform');
    }
    else {
        $c->render('chat/desktopform');
    }
}

sub desktop {
    my $c = shift;
    $c->session->{mobile} = 0;
    $c->redirect_to('chatform');
}

sub mobile {
    my $c = shift;
    $c->session->{mobile} = 1;
    $c->redirect_to('chatform');
}

1;

