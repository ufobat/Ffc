#!/usr/bin/perl 

#############################################################################
#############################################################################
####    Boilerplate und verwendete Module einbinden                      ####
#############################################################################
#############################################################################

use 5.010;
use strict;
use warnings;
use Mojo::JSON qw(decode_json);
use Mojolicious::Controller;
use DBI;
use Data::Dumper;
use File::Spec::Functions qw(catfile splitdir);
use File::Basename;
our @FileBase = splitdir( File::Basename::dirname(__FILE__) );
use lib catfile(@FileBase, '..', 'lib');
use Ffc::Data::Formats;



#############################################################################
#############################################################################
####    Ablauf des Migrationsabgleiches vorbereiten                      ####
#############################################################################
#############################################################################

#############################################################################
say "Konfigurationsdatei auslesen";
#############################################################################
our $Configfile = catfile(@FileBase, '..', 'etc', 'ffc.json');
our $Config = do {
    open my $fh, '<', $Configfile
        or die qq~Could not read open config file "$Configfile": $!~;
    local $/;
    decode_json <$fh>;
};

#############################################################################
say "Datenbankverbingungen herstellen";
#############################################################################
our $SDbh = DBI->connect(@{$Config}{qw(dsn user password)},
    { AutoCommit => 1, RaiseError => 1 });
$SDbh->{'mysql_enable_utf8'} = 1;

our $TDbh = DBI->connect('DBI:SQLite:database='
    . catfile(@FileBase, 'data', 'database.sqlite3'),
    '', '', { AutoCommit => 1, RaiseError => 1 });

#############################################################################
say "Übernahme-Anpassungs-Datenstrukturen vorbereiten";
#############################################################################
our %Gens = ( users => 1,  attachements => 0,  posts => 0,  topics => 0, );
our %Maps = ( users => {}, attachements => {}, posts => {}, topics => {} );

#############################################################################
say "Zieldatenbank leer räumen";
#############################################################################
$TDbh->do(qq~DELETE FROM "$_" WHERE "id">?~, undef, $Gens{$_})
    for qw(users attachements posts topics);



#############################################################################
#############################################################################
####    Migration der Daten schrittweise durchführen                     ####
#############################################################################
#############################################################################

#############################################################################
say "Datenabgleiche durchführen";
#############################################################################

mig_users();
mig_topics();
mig_posts();
mig_attachements();
say "Migration erfolgreich beendet, solange keine Warnungen kamen";
exit 0;



#############################################################################
#############################################################################
####    Hilfsroutinen für die folgenden Übernahmeschritte                ####
#############################################################################
#############################################################################

sub update_sequence {
    my $sname = shift;
#############################################################################
say qq~ - SQLite-Sequenz-Datensatz aktualisieren für "$sname"~;
#############################################################################
    $TDbh->do(
        'UPDATE "sqlite_sequence" SET "seq"=? WHERE "name"=?',
        undef, $Gens{$sname}, $sname);
}



#############################################################################
#############################################################################
####    Die einzelnen Migrationsschritte in Subroutinen                  ####
#############################################################################
#############################################################################


sub mig_users {
#############################################################################
say "Übernahme der Benutzerdatensätze";
#############################################################################
    say " - Benutzerdatensätze auslesen";
    my $users = $SDbh->selectall_arrayref( << 'EOSQL' );
    SELECT 
        `id`, `name`, '' AS `password`, `lastseen`, `active`, 
        `email`, `avatar`, `admin`, `bgcolor`
    FROM `ffc_users`;
EOSQL

    say " - Benutzerdatensätze einspielen";
    my $sth = $TDbh->prepare( << 'EOSQL' );
    INSERT INTO "users" 
        ("id", "name", "password", "lastseen", "active", "email",
        "avatar", "admin", "bgcolor")
    VALUES
        (?,?,?,?,?,?,?,?,?)
EOSQL
    $sth->execute(($Maps{users}{$_->[0]} = ++$Gens{users}), @{$_}[1..8])
        for @$users;

    say " - Kopiere die Avatarbildchen";
    my $sourcedir = catfile(@FileBase, '..', 'data', 'avatars');
    my $targetdir = catfile(@FileBase, 'data', 'avatars');
    if ( opendir my $dh, $sourcedir ) {
        for my $file ( readdir $dh ) {
            next if $file =~ m/\A\./xmsi or $file eq 'avatar_pics_placed_here';
            my $sourcefile = catfile(@FileBase, '..', 'data', 'avatars', $file);
            0 == system('cp', '-Rf', $sourcefile, $targetdir)
                or warn qq~! Avatardatei "$sourcefile" konnten nicht kopiert werden~;
        }
    }
    else {
        warn qq~! Konnte das Avatar-Quellverzeichnis "$sourcedir" nicht öffnen: $!~
    }

    update_sequence('users');
}

sub mig_topics {
#############################################################################
say "Übernahme der Kategorien/Themen";
#############################################################################
    say " - Kategoriedatensätze auslesen";
    my $cats = $SDbh->selectall_arrayref(
        'SELECT `id`, `name`, 1 as `userfrom` FROM `ffc_categories`');

    say " - Themendatensätze einspielen";
    my $sth = $TDbh->prepare(
        'INSERT INTO "topics" ("id", "title", "userfrom") VALUES (?,?,?);');

    $sth->execute(($Maps{topics}{$_->[0]} = ++$Gens{topics}), @{$_}[1,2])
        for @$cats;
    update_sequence('topics');
}

sub mig_posts {
#############################################################################
say "Übernahme der Datensätze für die Beiträge";
#############################################################################
    say " - Datensätze für Beiträge auslesen";
    my $posts = $SDbh->selectall_arrayref( << 'EOSQL' );
    SELECT
        `id`, `user_from`, `user_to`, `category`, 
        `posted`, `altered`, `textdata`, `textdata`
    FROM `ffc_posts`;
EOSQL

    say " - Datensätze für Beiträge einspielen";
    my $c = Mojolicious::Controller->new;
    my $sth = $TDbh->prepare( << 'EOSQL' );
    INSERT INTO "posts"
        ("id", "userfrom", "userto", "topicid", 
        "posted", "altered", "textdata", "cache")
    VALUES 
        (?,?,?,?,?,?,?,?);
EOSQL
    $sth->execute(
            ($Maps{posts}{$_->[0]} = ++$Gens{posts}),             # id
            $Maps{users}{$_->[1]},                               # userfrom
            (defined($_->[2]) ? $Maps{users}{$_->[2]} : undef),  # userto
            (defined($_->[3]) ? $Maps{topics}{$_->[3]} : undef), # topicid
            @{$_}[4,5,6],                       # posted, altered, textdata
            Ffc::Data::Formats::format_text(                     # cache
                # textdata, controller
                $_->[6], $c
            ),
        ) for @$posts;

    update_sequence('posts');
}

sub mig_attachements {
#############################################################################
say "Übernahme der Datensätze für Dateianhänge";
#############################################################################
    say " - Datensätze für die Dateianhänge auslesen";
    my $atts = $SDbh->selectall_arrayref( 
        'SELECT `postid`, `filename`, `number` FROM `ffc_attachements`;' );

    say " - Datensätze für Beiträge einspielen";
    my $sth = $TDbh->prepare(
        'INSERT INTO "attachements" ("id", "postid", "filename") VALUES (?,?,?);' );
    $sth->execute(
            ($Maps{attachements}{$_->[1]} = ++$Gens{attachements}), # id
            $Maps{posts}{$_->[0]},                                  # postid
            $_->[1],                                                # filename
        ) for @$atts;

    say " - Kopiere die Dateien";
    for my $att ( @$atts ) {
        my $sourcefile = catfile(@FileBase, '..', 'data', 'uploads', "$att->[0]-$att->[2]");
        unless ( -e $sourcefile ) {
            warn qq~! Dateianhang "$sourcefile" konnte nicht gefunden werden~;
            next;
        }
        my $targetfile = catfile(@FileBase, 'data', 'uploads', $Maps{attachements}{$att->[1]});
        0 == system('cp', '-f', $sourcefile, $targetfile)
            or warn qq~! Dateianhang "$sourcefile" konnten nicht nach "$targetfile" kopiert werden~;
    }

    update_sequence('attachements');
}
