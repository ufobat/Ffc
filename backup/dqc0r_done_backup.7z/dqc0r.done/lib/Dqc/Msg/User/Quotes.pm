package Dqc::Msg::User::Quotes;
use 5.010;
use strict;
use warnings;
use utf8;
use Dqc;
use Dqc::Msg;
srand;

our %Commands = (
    quote => sub {
        my @p;
        my $sql = 'SELECT zit_id FROM zit_zitate';
        if ( $_[1] ) {
            push @p, "\%$_[1]\%";
            $sql .= q~ WHERE LOWER(zit_text) LIKE LOWER(?)~;
        }
        my @ids = map { $_->[0] } @{ Dqc::dbh()->selectall_arrayref($sql, undef, @p) };
        my $i = @ids > 1 ? $ids[ int rand @ids ] : $ids[0];
        $sql = q~SELECT zit_text FROM zit_zitate WHERE zit_id=?~;
        my $q = Dqc::dbh()->selectall_arrayref($sql, undef, $i);
        if ( @$q ) {
            Dqc::Msg::add_msginfo("«$q->[0]->[0]»");
            return 'ok';
        }
        else {
            return 'Kein passendes Zitat gefunden';
        }
    },
    add_quote => sub {
        my $t = $_[1] || return 'Aufruf: "/add_quote Zitattext"';
        return 'Zitattext zu lang, darf nur 1024 Zeichen betragen' if 1024 < length $t;
        my $q = Dqc::dbh()->do('INSERT INTO zit_zitate (zit_text) VALUES (?)', undef, $t);
        Dqc::Msg::add_msginfo("«$t»");
        return 'Neues Zitat erstellt';
    },
    last_quote => sub {
        my $o = $_[1] =~ m/([1-9]\d*)/xmso ? $1 - 1 : 0;
        my $sql = 
        my $r = Dqc::dbh()->selectall_arrayref(q~SELECT zit_text FROM zit_zitate ORDER BY zit_id DESC LIMIT ?, 1~, undef, $o);
        if ( @$r ) {
            Dqc::Msg::add_msginfo("«$r->[0]->[0]»");
            return 'ok';
        }
        else {
            return 'Kein passendes Zitat gefunden';
        }
    },
);

1;

