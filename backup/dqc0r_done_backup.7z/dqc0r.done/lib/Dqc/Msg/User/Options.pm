package Dqc::Msg::User::Options;
use 5.010;
use strict;
use warnings;
use utf8;
use Dqc;
use Dqc::Auth;
use Dqc::Msg;

our %Commands = (
    set_refresh => sub {
        my ( $c, $t ) = @_;
        if ( $t =~ m/(\d+)/xms ) {
            $c->session->{refresh} = $1;
            Dqc::dbh()->do('UPDATE ben_benutzer SET ben_refresh=? WHERE ben_name=?', undef, $1, $c->session->{user});
            return qq'Refresh-Interval auf $1min gesetzt';
        }
        else {
            die qq'Aufruf: "/set_refresh #", wobei "#" eine Ganzzahl sein muss\n';
        }
    },
    set_pw => sub {
        my ( $c, $t ) = @_;
        my $u = $c->session->{user};
        my ( $po, $p1, $p2 ) = split /\s+/, $t;
        die qq'Aufruf: "/set_pw oldpassword password password"\n'
            unless $po and $p1 and $p2;
        die qq'Passwort konnte nicht gewechselt werden, da es mit der Wiederholung nicht stimmt\n'
            unless $p1 eq $p2;
        die qq'Altes Passwort ist nicht korrekt\n'
            unless Dqc::Auth::check_password($u, $po);
        Dqc::Auth::set_password($u, $p1);
        return 'Passwort geändert';
    },
    set_theme => sub {
        my $c = shift;
        my $t = substr shift() // '', 0, 32;
        die qq(Aufruf: "/set_theme themename") unless $t;
        $c->session->{theme} = $t;
        Dqc::dbh()->do('UPDATE ben_benutzer SET ben_theme=? WHERE ben_name=?', undef, $t, $c->session->{user});
        return qq(Style auf Thema "$t" gesetzt);
    },
    set_status => sub {
        my $c = shift;
        my $u = $c->session->{user};
        my $s = substr shift() // '', 0, 32;
        my %status = (
            busy => '%s ist jetzt tierisch am rackern',
            feierabend => '%s geht jetzt heim',
            lunch => '%s geht jetzt zum Futtertrog',
            sleep => '%s folgt jetzt seiner Bestimmung',
            meeting => '%s geht Kaffee trinken',
            away => '%s macht sich erstmal aus dem Staub',
            hidden => '%s macht jetzt einen auf Sam Fisher',
        );
        Dqc::dbh()->do('UPDATE ben_benutzer SET ben_status=? WHERE ben_name=?', undef, $s, $u);
        Dqc::Msg::add_msginfo(
            $status{$s} 
                ? sprintf($status{$s}, $u)
                : $s 
                    ? qq(Benutzer "$u" hat seinen Status auf "$s" gesetzt) 
                    : qq(Benutzer "$u" ist wieder da)
        );
        return $s ? qq(Status auf "$s" gesetzt) : q(Status gesetzt);
    },
);

1;


