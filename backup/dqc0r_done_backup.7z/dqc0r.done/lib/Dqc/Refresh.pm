package Dqc::Refresh;
use Mojo::Base 'Mojolicious::Controller';
use Mojo::Util;
use File::Spec::Functions 'catfile';

sub get_refresh         { _get_refresh( $_[0], 1 ) }
sub get_refresh_nofocus { _get_refresh( $_[0], 0 ) }
sub _get_refresh {
    my $c = shift;
    my $focus = shift;
    my $u = $c->session->{user};
    my $t = $c->session->{theme};

    if ( $focus ) {
        Dqc::dbh()->do(
            'UPDATE ben_benutzer SET ben_lastseenfocus=?, ben_lastseen=? WHERE ben_name=?',
            undef, (time) x 2, $u
        );
    }
    else {
        Dqc::dbh()->do(
            'UPDATE ben_benutzer SET ben_lastseen=? WHERE ben_name=?',
            undef, time, $u
        );
    }

    my $users = get_userlist();

    my $msgs = Dqc::dbh()->selectall_arrayref(
        'SELECT nrn_id, nrn_zeit, ben_name, nrn_text
        FROM nrn_nachrichten
        LEFT OUTER JOIN ben_benutzer ON ben_id = nrn_von
        WHERE nrn_id > (SELECT ben_lastid FROM ben_benutzer WHERE ben_name=? LIMIT 1)
        ORDER BY nrn_id DESC
        LIMIT 100',
        undef, $u
    );

    if ( @$msgs ) {
        Dqc::dbh()->do(
            'UPDATE ben_benutzer SET ben_lastid=? WHERE ben_name=?',
            undef, ( $msgs->[0]->[0] // 0 ), $u
        );
    }

    $msgs = [map {
        $_->[1] = sprintf '%02d:%02d', (localtime($_->[1]))[2,1];
        $_->[2] = Mojo::Util::xml_escape($_->[2]) if $_->[2];
        $_->[3] = Mojo::Util::xml_escape($_->[3]);
        $_->[3] =~ s~\n+~<br />~xmsog;
        [@{$_}[1,2,3]]
    } reverse @$msgs];
    for ( @$users ) {
        $_->[0] = Mojo::Util::xml_escape($_->[0]);
    }

    my $z = Dqc::dbh()->selectall_arrayref( q[SELECT dat_zahl FROM dat_datenfelder WHERE dat_schluessel='zeichenanzahl'] )->[0]->[0];
    my $n = Dqc::dbh()->selectall_arrayref( 'SELECT COUNT(ntz_id) FROM ntz_notizen' )->[0]->[0]; 
    my $s = Dqc::dbh()->selectall_arrayref( 'SELECT COUNT(pre_id) FROM pre_codeparts' )->[0]->[0]; 
    my $f = Dqc::dbh()->selectall_arrayref( 'SELECT COUNT(upl_id) FROM upl_uploadfiles' )->[0]->[0]; 
    my $p = Dqc::dbh()->selectall_arrayref( 
        'SELECT COUNT(prv_id)
        FROM prv_privatnachrichten
        INNER JOIN ben_benutzer ba ON prv_an=ba.ben_id
        WHERE ba.ben_name=? AND ba.ben_lastprvid<prv_id',
        undef, $u
    )->[0]->[0]; 

    $c->render( json => [ [ $u, $t, $n, $p, $z, $s, $f ], $users, $msgs ] );
}

sub get_notes {
    $_[0]->render( json => [ map {
        my @t = localtime $_->[1]; $t[4]++; $t[5] += 1900;
        $_->[1] = sprintf '%02d.%02d.%04d', @t[3,4,5];
        $_;
    } @{ Dqc::dbh()->selectall_arrayref(
        'SELECT ntz_id, ntz_zeit, ben_name, ntz_text
        FROM ntz_notizen
        INNER JOIN ben_benutzer ON ntz_von=ben_id
        ORDER BY ntz_id DESC'
    ) } ] );
}

sub get_prvmsgs {
    my $c = shift;
    my $u =  $c->session()->{user};

    my $prvmsgs = Dqc::dbh()->selectall_arrayref(
        'SELECT prv_id, prv_zeit, bv.ben_name, ba.ben_name, prv_text
        FROM prv_privatnachrichten
        INNER JOIN ben_benutzer bv ON prv_von=bv.ben_id
        INNER JOIN ben_benutzer ba ON prv_an=ba.ben_id
        WHERE ( bv.ben_name=? AND bv.ben_lastprvid < prv_id ) OR ( ba.ben_name=? AND ba.ben_lastprvid<prv_id )
        ORDER BY prv_id DESC',
        undef, $u, $u
    );
    
    if ( @$prvmsgs ) {
        Dqc::dbh()->do(
            'UPDATE ben_benutzer SET ben_lastprvid=? WHERE ben_name=?',
            undef, ( $prvmsgs->[0]->[0] // 0 ), $u
        );
    }

    $prvmsgs = [ $u, map {
        $_->[1] = sprintf '%02d:%02d', (localtime($_->[1]))[2,1];
        [@{$_}[1,2,3,4]];
    } @$prvmsgs ]
        if @$prvmsgs;
        
    $c->render( json => $prvmsgs );
}

sub get_codelist {
    shift()->render( json => [
        map { [
            $_->[0],
            Mojo::Util::xml_escape( "$_->[1] (".do{
                my @t = localtime($_->[2]); $t[5]+=1900; $t[4]++;
                sprintf '%02d:%02d, %02d.%02d.%04d', @t[2,1,3,4,5]
            }."): "
            .substr( ( split /\n+/, $_->[3], 2 )[0] // '', 0, 256 ) ),
        ] }
        @{ Dqc::dbh()->selectall_arrayref(
            'SELECT pre_id, ben_name, pre_zeit, pre_text
            FROM pre_codeparts
            INNER JOIN ben_benutzer ON ben_id = pre_von
            ORDER BY pre_zeit DESC, pre_id DESC'
        ) }
    ] );
}

sub get_codetext {
    my $c = shift;
    my $dat = Dqc::dbh()->selectall_arrayref(
        'SELECT pre_text FROM pre_codeparts WHERE pre_id=?', undef, $c->param('codeid')
    );
    $c->render( json => [ @$dat ? $dat->[0]->[0] : '' ] ); 
}

sub get_filelist {
    shift()->render(json => [
        map { [
            $_->[0],
            Mojo::Util::xml_escape( "$_->[1] (".do {
                my @t = localtime($_->[2]); $t[5]+=1900; $t[4]++;
                sprintf '%02d:%02d, %02d.%02d.%04d', @t[2,1,3,4,5]
            }."): "
            .$_->[3])
        ] }
        @{ Dqc::dbh()->selectall_arrayref(
            'SELECT upl_id, ben_name, upl_zeit, upl_name
            FROM upl_uploadfiles
            INNER JOIN ben_benutzer ON ben_id = upl_von
            ORDER BY upl_id DESC'
        ) }
    ] );
}

sub get_file {
    my $c = shift;
    my $id = $c->param('fileid');
    my $filename = Dqc::dbh()->selectall_arrayref('SELECT upl_name FROM upl_uploadfiles WHERE upl_id=?', undef, $id);
    my $filepath = catfile($Dqc::RootPath,'uploads',$id);
    $filename = @$filename ? $filename->[0]->[0] : '';
    if ( $filename and -e $filepath ) {
        my $file = Mojo::Asset::File->new(path => $filepath);
        my $headers = Mojo::Headers->new(); 
        $headers->add( 'Content-Disposition', qq~attachment; filename=$filename~ );
        $headers->add( 'Content-Length' => $file->size );
        $c->res->content->headers($headers);
        $c->res->content->asset($file);
        $c->rendered(200);
    }
    else {
        $c->res->code(404);
        $c->res->message('File Not Found');
        if ( $filename ) {
            $c->render(json => qq'File "$filename" Not Found In Storage');
        }
        else {
            $c->render(json => qq'File $id Not Found In Database');
        }
    }
}

sub get_userlist {
    return [ map {
        $_->[2] = sprintf '%02d:%02d', (localtime($_->[2] - (($_[1]//0) * 60)))[2,1];
        $_;
    } @{
        Dqc::dbh()->selectall_arrayref(
            'SELECT ben_name, ben_refresh, ben_lastseenfocus, ben_admin, ben_status
            FROM ben_benutzer
            WHERE ben_lastseen >= ? - ben_refresh * 60 - 20
            ORDER BY ben_name ASC',
            undef, time
        )
    } ];
}

1;
