package Dqc::Msg::Admin;
use 5.010;
use strict;
use warnings;
use utf8;
use Dqc;

our %Commands = (
    add_user => sub {
        my ( $c, $t ) = @_;
        my ( $u, $p1, $p2 ) = split /\s+/, $t;
        die qq'Aufruf: "/add_user username password password"\n'
            unless $u and $p1 and $p2;
        die qq'Benutzer "$u" konnte nicht erstellt werden, Passwortwiederholung stimmt nicht\n'
            unless $p1 eq $p2;
        Dqc::Auth::add_user($u, $p1);
        return qq'Benutzer "$u" erstellt';
    },
    mod_user => sub {
        my ( $c, $t ) = @_;
        my ( $u, $p1, $p2 ) = split /\s+/, $t;
        die qq'Aufruf: "/mod_user username password password"\n'
            unless $u and $p1 and $p2;
        die qq'Benutzer "$u" konnte nicht geändert werden, Passwortwiederholung stimmt nicht\n'
            unless $p1 eq $p2;
        Dqc::Auth::set_password($u, $p1);
        return qq'Benutzer "$u" geändert';
    },
    set_admin => sub {
        my ( $c, $t ) = @_;
        my ( $u, $p ) = split /\s+/, $t;
        if ( defined($p) and $p =~ m/\A\s*([01])/xms ) {
            Dqc::Auth::set_admin($u, $p);
        return $p 
            ? qq'Benutzer "$u" auf Admin gesetzt'
            : qq'Benutzer "$u" Admin entzogen';
        }
        else {
            die qq'Aufruf "/set_admin username 0" (Admin-Rechte entziehen) oder "/set_admin username 1" (Admin-Rechte gewähren)\n'
        }
    },
    help_admin => sub {
        return << 'EOHELP';
Administratorenhilfe:
  /add_user username password password: Benutzer anlegen
  /mod_user username password password: Benutzer ändern
  /set_admin username (0|1): Benutzer-Admin-Status ändern
EOHELP
    },
);

1;

