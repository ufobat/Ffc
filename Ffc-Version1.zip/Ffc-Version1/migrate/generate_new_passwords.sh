#!/bin/bash
file=Userlist.txt
echo '================================================================================' > $file
echo >> $file
sqlite3 -separator ' ' data/database.sqlite3 'SELECT name,email FROM users ORDER BY name;'|grep -v admin|perl -lanE 'my @chrs = (36..38,40..90,95,97..122); print "$F[1]\n\n" if $F[1]; say qq~Hallo "$F[0]",\n\ndein initiales neues Passwort für die neue Version der Forensoftware lautet "~.join("",map {chr $chrs[int rand $#chrs]} 1..12).qq~" (ohne Gänsefüßchen).\n\nBitte notiere dir dieses Passwort und verwende es, sobald die neue Version der Forensoftware produktiv geschalten ist. Darauf wird rechtzeitig vorher noch hingewiesen.\n\nBitte informiere mich auch, wenn du diese Email gelesen hast, zu Bestätigung, sozusagen.\n\nWenn die Umstellung stattgefunden hat, dann melde dich bitte mit diesem neuen Passwort und deiner alten Kennung an und setze das Passwort entsprechend im Menü unter Optionen wieder auf ein eigenes selbstgewähltes Passwort.\n\nDanke für deine Aufmerksamkeit, man liest sich.\n\nEuer Foren-Admin.~;say "";say "=" x 80;say "";' >> $file
echo Benutzerinfomailinhalte erstellt
