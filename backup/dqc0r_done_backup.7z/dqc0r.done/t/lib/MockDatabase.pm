package MockDatabase;
use 5.010;
use strict;
use warnings;
use utf8;
use FindBin;

use Test::Mojo;

use lib "$FindBin::Bin/../lib";
use lib "$FindBin::Bin/../t/lib";

$ENV{DQC_CONFIG} = "$FindBin::Bin/../t/etc/config.json";
my $t = Test::Mojo->new('Dqc');

Dqc::dbh()->do( << 'EOSQL' );
CREATE TABLE IF NOT EXISTS "ben_benutzer" (
  "ben_id" INTEGER PRIMARY KEY AUTOINCREMENT,
  "ben_name" varchar(32) NOT NULL,
  "ben_passwort" varchar(1024) NOT NULL,
  "ben_admin" smallint(6) NOT NULL DEFAULT '0',
  "ben_lastid" integer NOT NULL DEFAULT '0',
  "ben_lastprvid" integer NOT NULL DEFAULT 0,
  "ben_lastseen" integer NOT NULL DEFAULT 0,
  "ben_lastseenfocus" integer NOT NULL DEFAULT 0,
  "ben_refresh" integer NOT NULL DEFAULT '1',
  "ben_theme" varchar(256) NOT NULL DEFAULT '',
  "ben_status" varhchar(32) NOT NULL DEFAULT '',
  UNIQUE ("ben_name")
);
EOSQL

Dqc::dbh()->do( << 'EOSQL' );
CREATE TABLE IF NOT EXISTS "nrn_nachrichten" (
  "nrn_id" integer PRIMARY KEY AUTOINCREMENT,
  "nrn_von" integer DEFAULT NULL,
  "nrn_zeit" integer NOT NULL DEFAULT 0,
  "nrn_text" varchar(2048) NOT NULL
);
EOSQL

Dqc::dbh()->do( << 'EOSQL' );
CREATE TABLE IF NOT EXISTS "ntz_notizen" (
  "ntz_id" integer PRIMARY KEY AUTOINCREMENT,
  "ntz_von" integer DEFAULT NULL,
  "ntz_zeit" integer NOT NULL DEFAULT 0,
  "ntz_text" varchar(2048) NOT NULL
);
EOSQL

Dqc::dbh()->do( << 'EOSQL' );
CREATE TABLE IF NOT EXISTS "pre_codeparts" (
  "pre_id" integer PRIMARY KEY AUTOINCREMENT,
  "pre_von" integer DEFAULT NULL,
  "pre_zeit" integer NOT NULL DEFAULT 0,
  "pre_text" varchar(4096) NOT NULL
);
EOSQL

Dqc::dbh()->do( << 'EOSQL' );
CREATE TABLE IF NOT EXISTS "upl_uploadfiles" (
  "upl_id" integer PRIMARY KEY AUTOINCREMENT,
  "upl_von" integer DEFAULT NULL,
  "upl_zeit" integer NOT NULL DEFAULT 0,
  "upl_name" varchar(512) NOT NULL
);
EOSQL

Dqc::dbh()->do( << 'EOSQL' );
CREATE TABLE "prv_privatnachrichten" (
  "prv_id" integer PRIMARY KEY AUTOINCREMENT,
  "prv_von" integer DEFAULT NULL,
  "prv_an" integer NOT NULL,
  "prv_zeit" integer NOT NULL DEFAULT 0,
  "prv_text" varchar(2048) NOT NULL
);
EOSQL

Dqc::dbh()->do( << 'EOSQL' );
CREATE TABLE "dat_datenfelder" (
  "dat_schluessel" varchar(32) PRIMARY KEY,
  "dat_zahl" integer,
  "dat_zeichenkette" varchar(256)
);
EOSQL

Dqc::dbh()->do( << 'EOSQL' );
CREATE TABLE "zit_zitate" (
  "zit_id" integer PRIMARY KEY AUTOINCREMENT,
  "zit_text" varchar(1024) NOT NULL,
  UNIQUE ("zit_text")
);
EOSQL

Dqc::dbh()->do( << 'EOSQL' );
INSERT INTO "dat_datenfelder" ("dat_schluessel", "dat_zahl") VALUES ('zeichenanzahl', 0)
EOSQL

sub get_t { $t }

1;

