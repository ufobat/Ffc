package Dqc::Msg::User::Notes;
use 5.010;
use strict;
use warnings;
use utf8;
use Dqc;
use Dqc::Msg;

our %Commands = (
    add_note => sub {
        my $u = shift()->session()->{user};
        my $t = shift;
        die 'Aufruf: "/add_note Notiztext"'
            unless $t;
        Dqc::dbh()->do(
            'INSERT INTO ntz_notizen (ntz_von, ntz_text, ntz_zeit) VALUES ((SELECT ben_id FROM ben_benutzer WHERE ben_name=? LIMIT 1),?,?)',
            undef, $u, $t, time );
        Dqc::Msg::add_msginfo("$u hat eine neue Notiz erstellt");
        return 'Neue Notiz erstellt';
    },
    del_note => sub {
        die 'Notiz-Id muss eine Zahl sein'
            unless $_[1] =~ m/(\d+)/xms;
        Dqc::dbh()->do(
            'DELETE FROM ntz_notizen WHERE ntz_id=?',
            undef, $1 );
        Dqc::Msg::add_msginfo($_[0]->session()->{user}.' hat eine Notiz gelöscht');
        return qq'Notiz $1 entfernt';
    },
);

1;

