package Dqc::Msg::User::Code;
use 5.010;
use strict;
use warnings;
use utf8;
use Dqc;
use Dqc::Msg;

our %Commands = (
    add_code => sub {
        my $u = shift()->session()->{user};
        my $t = shift;
        die 'Aufruf: "/add_code Quelltext"'
            unless $t;
        Dqc::dbh()->do(
            'INSERT INTO pre_codeparts (pre_von, pre_text, pre_zeit) VALUES ((SELECT ben_id FROM ben_benutzer WHERE ben_name=? LIMIT 1),?,?)',
            undef, $u, $t, time );
        Dqc::Msg::add_msginfo("$u hat ein Codeschnippsel hinzugefügt");
        return 'Neues Codeschnippet erstellt';
    },
    del_code => sub {
        my $i;
        if ( $_[1] and $_[1] =~ m/\A\s*(\d+)\s*\z/xmso ) {
            $i = $1;
        }
        else {
            die 'Aufruf: "/del_code #" zum Löschen';
        }
        Dqc::dbh()->do( 'DELETE FROM pre_codeparts WHERE pre_id=?', undef, $i );
        Dqc::Msg::add_msginfo($_[0]->session()->{user}.' hat ein Codeschnippsel gelöscht');
        return 'Codeschnippet gelöscht';
    },
    code => sub {
        my $u = shift()->session()->{user};
        my ( $i, $t ) = split /\s+/, shift(), 2;
        die 'Aufruf: "/code # Quelltext" zum Ändern' unless $i =~ m/\A\d+\z/xmso and $t;
        Dqc::dbh()->do(
            'UPDATE pre_codeparts SET pre_von=(SELECT ben_id FROM ben_benutzer WHERE ben_name=? LIMIT 1), pre_text=?, pre_zeit=? WHERE pre_id=?',
            undef, $u, $t, time(), $i );
        Dqc::Msg::add_msginfo("$u hat ein Codeschnippsel geändert");
        return 'Codeschnippet geändert';
    },
);

