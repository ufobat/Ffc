function select_privmsg_to(user) {
    $('#privusername').val(user);
}
function open_privmsg_to(user) {
    $('#privusername').val(user);
    open_privates_user(0);
}
function open_privates() {
    open_privates_user(1);
}
function open_privates_user(wu) {
    if ( wu )
        get_privates_wu();
    else
        get_privates_wo();

    privatesdialog = 1;
    $('#privates').dialog({beforeClose:function(e,ui){privatesdialog = 0}, width:'32em',disabled:false});
}
function send_priv() {
    var msg = $('#privmsgtext').val();
    var usr = $('#privusername').val();
    if ( !msg ) {
        alert('Private Nachricht ist leer');
        return 'private message empty';
    }
    if ( !usr ) {
        alert('Bitte Benutzer auswählen');
        return 'private message user not selected';
    }
    $('#privmsgtext').val('');
    ajax_send_with_fun('/msg '+usr+' '+msg, get_privates_wo);
}

function open_uploads() {
    get_filelist();
    $('#files').dialog({width:'42em', disabled:false});
}

function open_codes() {
    get_codelist();
    $('#codes').dialog({width:'48.5em', disabled:false});
}

function open_notes() {
    get_notes();
    $('#notes').dialog({width:'32em',disabled:false});
}
function add_notes_click() {
    var notes = $('#add_notes_text').val();
    if ( !notes ) {
        alert('Notiz ist leer');
        return 'note empty';
    }
    ajax_send_with_fun('/add_note '+notes, get_notes);
    $('#add_notes_text').val('');
}

function save_code_text() {
    var id =  $('#codelist').val();
    var txt =  $('#codetext').val();
    if ( !txt ) {
        if ( id ) {
            ajax_send_with_fun('/del_code '+id, get_codelist);
            return 'code deleted';
        }
        else {
            alert('Kein Codeschnippet zum Löschen ausgewählt')
            return 'no code selected';
        }
    }
    else {
        if ( id ) {
            ajax_send_with_fun('/code '+id+' '+txt, get_codelist);
            return 'code changed';
        }
        else {
            ajax_send_with_fun('/add_code '+txt, get_codelist);
            return 'code added';
        }
    }
}

function del_note(val) { 
    if ( confirm("Wollen Sie die Notiz wirklich löschen?") ) {
        ajax_send_with_fun('/del_note '+val, get_notes);
    }
}

function del_upload(val) { 
    if ( confirm("Wollen Sie die Datei wirklich löschen?") ) {
        ajax_send_with_fun('/del_file '+val, get_filelist);
    }
}

function open_options() {
    $('#optionen').dialog({width:'32em',disabled:false});
}

function change_pw() {
    var oldpw = $('#oldpw').val();
    $('#oldpw').val('');
    var newpw1 = $('#newpw1').val();
    $('#newpw1').val('');
    var newpw2 = $('#newpw2').val();
    $('#newpw2').val('');
    ajax_send('/set_pw '+oldpw+' '+newpw1+' '+newpw2);
    close_options();
}

function alter_stylesheet(style) {
    ajax_send('/set_theme '+style);
}

function set_refresh(val) {
    ajax_send('/set_refresh '+val);
}

function set_status(val) {
    ajax_send('/set_status '+val);
}

function chuck() {
    ajax_send('/quote Chuck Norris');
}

