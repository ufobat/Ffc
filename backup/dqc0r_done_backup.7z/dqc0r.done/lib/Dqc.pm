package Dqc;
use Mojo::Base 'Mojolicious';
use File::Spec::Functions qw(catfile splitdir);
use File::Basename;
use Digest::SHA 'sha512_base64';
use DBI;
use Dqc::Auth;

our $RootPath =  catfile( splitdir( File::Basename::dirname(__FILE__) ), '..' );
our $ConfigPath = $ENV{DQC_CONFIG} || catfile( $RootPath, 'etc', 'config.json' );
our $ThemeUrl = '/themes/';
our $Config = {};

{
    my ( $dbh, $dsn,$user, $pass, $salt );
    sub set_dbconfig {
        for my $p ([dsn=>\$dsn],[user=>\$user],[password=>\$pass],[cryptsalt=>\$salt]) {
            ${$p->[1]} = $Config->{$p->[0]};
            delete $Config->{$p->[0]};
        }
    }
    sub dbh {
        return $dbh if $dbh;
        $dbh = DBI->connect($dsn, $user, $pass, {RaiseError => 1, AutoCommit => 1});
        $dbh->{'mysql_enable_utf8'} = 1;
        return $dbh;
    }
    sub password { sha512_base64($_[0], $salt) }
}

sub set_config {
    my $app = shift;
    # app preparation
    $Config = $app->plugin( JSONConfig => { file => $ConfigPath } );
    set_dbconfig();
}

sub startup {
    my $app = shift;
    $app->set_config;
    $app->secrets(['Dqc0r rocks! Auch wenn der Dani immer wieder so wettert :(']);
    if ( $Config->{debug} ) {
        $app->mode('development');
    }
    else {
        $app->mode('production');
    }

    my $r = $app->routes;

    # login and logout
    $r->post('/login')->to('auth#login')->name('login');
    my $l = $r->under(\&Dqc::Auth::check)->name('loggedin_bridge');
    $l->get('/logout')->to('auth#logout')->name('logout');

    # chat form, message processing and refresh request
    $l->get('/')->to('chat#chatform')->name('chatform');
    $l->get('/mobile')->to('chat#mobile')->name('mobile');
    $l->get('/desktop')->to('chat#desktop')->name('desktop');
    $l->post('/msg')->to('msg#process')->name('msg');
    $l->get('/refresh')->to('refresh#get_refresh')->name('refresh');
    $l->get('/refresh_nofocus')->to('refresh#get_refresh_nofocus')->name('refresh_nofocus');
    $l->get('/notes')->to('refresh#get_notes')->name('notes');
    $l->get('/privat')->to('refresh#get_prvmsgs')->name('prvmsgs');
    $l->get('/codelist')->to('refresh#get_codelist')->name('codelist');
    $l->get('/codetext/:codeid', [codeid => qr/\d+/])->to('refresh#get_codetext')->name('codetext');
    $l->get('/filelist')->to('refresh#get_filelist')->name('filelist');
    $l->get('/file/:fileid', [fileid => qr/\d+/])->to('refresh#get_file')->name('getfile');
    $l->get('/delfile/:fileid', [fileid => qr/\d+/])->to('msg#delete_upload')->name('deletefile');
    $l->get('/uploadform')->to('msg#upload_form')->name('uploadform');
    $l->post('/upload')->to('msg#upload_file')->name('uploadfile');
}

1;
