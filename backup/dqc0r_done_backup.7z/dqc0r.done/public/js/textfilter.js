function textfilter(txt) {
    txt = txt.replace(/\[b\](.+?)\[\/b\]/g, '<span class="tbold">$1</span>');
    txt = txt.replace(/\[i\](.+?)\[\/i\]/g, '<span class="titalic">$1</span>');
    txt = txt.replace(/\[u\](.+?)\[\/u\]/g, '<span class="tunderline">$1</span>');
    txt = txt.replace(/(([\(|\s])?|^)(https?:\/\/[^\)\s]+?)(\)|,?\s|$)/g, '$1<a href="$3" target="_blank" title="Externe Webadresse! ($3)">$3</a>$4');
    return(txt);
}

