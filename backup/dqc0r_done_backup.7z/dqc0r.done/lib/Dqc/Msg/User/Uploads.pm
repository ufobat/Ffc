package Dqc::Msg::User::Uploads;
use 5.010;
use strict;
use warnings;
use utf8;
use Dqc;
use Dqc::Msg;
use File::Spec::Functions 'catfile';

our %Commands = (
    del_file => sub {
        my $i;
        if ( $_[1] and $_[1] =~ m/\A\s*(\d+)\s*\z/xmso ) {
            $i = $1;
        }
        else {
            die 'Aufruf: "/del_file #" zum Löschen';
        }
        my $file = catfile($Dqc::RootPath,'uploads',$i);
        unlink $file or die "$file: $!";
        Dqc::dbh()->do('DELETE FROM upl_uploadfiles WHERE upl_id=?', undef, $i);
        Dqc::Msg::add_msginfo($_[0]->session()->{user}.' hat eine Datei gelöscht');
        return 'Datei gelöscht';
    },
);

