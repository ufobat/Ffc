-- phpMyAdmin SQL Dump
-- version 3.3.7deb7
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Erstellungszeit: 26. März 2014 um 15:02
-- Server Version: 5.1.73
-- PHP-Version: 5.3.3-7+squeeze19

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Datenbank: `dqc`
--

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `ben_benutzer`
--

CREATE TABLE IF NOT EXISTS `ben_benutzer` (
  `ben_id` int(11) NOT NULL AUTO_INCREMENT,
  `ben_name` varchar(32) NOT NULL,
  `ben_passwort` varchar(1024) NOT NULL,
  `ben_admin` smallint(6) NOT NULL DEFAULT '0',
  `ben_lastid` bigint(20) NOT NULL DEFAULT '0',
  `ben_lastprvid` bigint(20) NOT NULL DEFAULT '0',
  `ben_lastseen` int(11) NOT NULL DEFAULT '0',
  `ben_lastseenfocus` int(11) NOT NULL DEFAULT '0',
  `ben_refresh` int(11) NOT NULL DEFAULT '1',
  `ben_theme` varchar(256) NOT NULL DEFAULT '',
  `ben_status` varchar(32) NOT NULL DEFAULT '',
  PRIMARY KEY (`ben_id`),
  UNIQUE KEY `ben_name` (`ben_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `dat_datenfelder`
--

CREATE TABLE IF NOT EXISTS `dat_datenfelder` (
  `dat_schluessel` varchar(32) NOT NULL,
  `dat_zahl` int(11) NOT NULL,
  `dat_zeichenkette` varchar(256) NOT NULL,
  PRIMARY KEY (`dat_schluessel`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `nrn_nachrichten`
--

CREATE TABLE IF NOT EXISTS `nrn_nachrichten` (
  `nrn_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nrn_zeit` int(11) NOT NULL DEFAULT '0',
  `nrn_von` int(11) DEFAULT NULL,
  `nrn_text` varchar(2048) NOT NULL,
  PRIMARY KEY (`nrn_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `ntz_notizen`
--

CREATE TABLE IF NOT EXISTS `ntz_notizen` (
  `ntz_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ntz_von` int(11) DEFAULT NULL,
  `ntz_zeit` int(11) NOT NULL,
  `ntz_text` varchar(2048) NOT NULL,
  PRIMARY KEY (`ntz_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `pre_codeparts`
--

CREATE TABLE IF NOT EXISTS `pre_codeparts` (
  `pre_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `pre_von` int(11) DEFAULT NULL,
  `pre_zeit` int(11) NOT NULL,
  `pre_text` varchar(2048) NOT NULL,
  PRIMARY KEY (`pre_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `prv_privatnachrichten`
--

CREATE TABLE IF NOT EXISTS `prv_privatnachrichten` (
  `prv_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `prv_von` int(11) DEFAULT NULL,
  `prv_an` int(11) NOT NULL,
  `prv_zeit` int(11) NOT NULL DEFAULT '0',
  `prv_text` varchar(2048) NOT NULL,
  PRIMARY KEY (`prv_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `upl_uploadfiles`
--

CREATE TABLE IF NOT EXISTS `upl_uploadfiles` (
  `upl_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `upl_von` int(11) DEFAULT NULL,
  `upl_zeit` int(11) NOT NULL,
  `upl_name` varchar(256) NOT NULL,
  PRIMARY KEY (`upl_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `zit_zitate`
--

CREATE TABLE IF NOT EXISTS `zit_zitate` (
  `zit_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `zit_text` varchar(1024) NOT NULL,
  UNIQUE KEY `zit_id` (`zit_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Initialwert für Zeichenanzahl-Zähler
--

INSERT INTO "dat_datenfelder" ("dat_schluessel", "dat_zahl") VALUES ('zeichenanzahl', 0);
