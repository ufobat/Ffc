package Dqc::Msg;
use Mojo::Base 'Mojolicious::Controller';
use Dqc;
use Dqc::Msg::User;
use Dqc::Msg::Admin;
use Mojo::Util;
use File::Spec::Functions 'catfile';

sub process {
    my $c = shift;
    my $d = $c->param('data') // '';

    if ( not length $d ) {
        $c->render( json => 'Nachricht zu kurz' );
    }
    elsif ( 2048 < length $d ) {
        $c->render( json => 'Nachricht zu lang (max 2048 Zeichen)' );
    }
    elsif ( $d =~ m~\A/~xms ) {
        $d =~ m~(\w+)\s*(.{0,2048}?)\s*\z~xms;
        my $cmd = $1; my $text = $2;
        my %commands = ( %Dqc::Msg::User::Commands, $c->session->{admin} ? %Dqc::Msg::Admin::Commands : () );
        if ( exists $commands{$cmd} ) {
            my $code = $commands{$cmd};
            local $@;
            my $r;
            eval { $r = $code->($c, $text) };
            if ( $@ ) {
                $r = qq'Fehler bei der Ausführung von Kommando "$cmd": $@';
            }
            if ( $r ) {
                chomp $r;
                $r = Mojo::Util::xml_escape($r);
                $r =~ s~\n+~<br />~xmsg;
            }
            else {
                $r = qq'Kommando \&quot;$cmd\&quot; ausgeführt';
            }
            $c->render( json => $r );
        }
        else {
            $c->render( json => qq'Fehler: Kommando \&quot;$cmd\&quot; unbekannt' );
        }
    }
    else {
        _add_msg( $c->session->{user}, $d );
        $c->render( json => 'ok' );
    }
}

sub add_msginfo { _add_msg( undef, @_ ) }
sub _add_msg {
    my ( $u, $m ) = @_;
    if ( $u ) {
        Dqc::dbh()->do(
            'INSERT INTO nrn_nachrichten (nrn_von, nrn_text, nrn_zeit) VALUES ((SELECT ben_id FROM ben_benutzer WHERE ben_name=? LIMIT 1), ?, ?)',
            undef, $u, $m, time
        );
        Dqc::dbh()->do(
            q{UPDATE dat_datenfelder SET dat_zahl = dat_zahl + ? WHERE dat_schluessel='zeichenanzahl'},
            undef, length $m
        );
    }
    else {
        Dqc::dbh()->do(
            'INSERT INTO nrn_nachrichten (nrn_text, nrn_zeit) VALUES (?, ?)',
            undef, $m, time
        );
    }
}

sub upload_file {
    my $c = shift;
    my $u = $c->session()->{user};
    my $file = $c->param('uploadfile');
    if ( $file and my $filename = $file->filename ) {
        my $dbh = Dqc::dbh();
        $dbh->do(
            'INSERT INTO upl_uploadfiles (upl_von, upl_zeit, upl_name) VALUES ((SELECT ben_id FROM ben_benutzer WHERE LOWER(ben_name)=LOWER(?) LIMIT 1),?,?)', undef, $u, time, $filename
        );
        my $id = $dbh->last_insert_id(undef, undef, undef, undef) or die 'No id got for upload';
        eval { $file->move_to(catfile($Dqc::RootPath,'uploads',$id)) };
        if ( $@ ) {
            $c->stash(uploadok => "Fehler: $@");
        }
        else {
            add_msginfo(qq~$u hat die Datei "$filename" hochgeladen~);
            $c->stash(uploadok => $filename);
        }
    }
    else {
        $c->stash(uploadok => '');
    }
    $c->render('chat/uploadform');
}
sub upload_form {
    my $c = shift;
    $c->stash(uploadok => '');
    $c->render('chat/uploadform');
}

1;
