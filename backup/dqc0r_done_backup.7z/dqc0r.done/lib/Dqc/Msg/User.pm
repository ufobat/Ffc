package Dqc::Msg::User;
use 5.010;
use strict;
use warnings;
use utf8;
use Dqc;
use Dqc::Auth;
use Dqc::Refresh;
use Dqc::Msg;
use Dqc::Msg::User::Notes;
use Dqc::Msg::User::Privmsgs;
use Dqc::Msg::User::Options;
use Dqc::Msg::User::Code;
use Dqc::Msg::User::Quotes;
use Dqc::Msg::User::Uploads;

our %Commands = (
    me => sub {
        my $u = shift()->session->{user};
        my $t = shift;
        die 'Nachricht ist zu kurz'
            unless $t;
        Dqc::Msg::add_msginfo("$u $t");
        return 'ok';
    },
    userlist => sub {
        my $u = shift()->session->{user};
        my $list = Dqc::Refresh::get_userlist();
        return @$list
            ? join "\n", 'Angemeldete Benutzer:', map {
                  ( $u      eq $_->[0] ? '> '  : '' ) 
                . ( $_->[3] == 1       ? '@'   : '' )
                .   "$_->[0] ("
                . ( $_->[1] > 1440     ? 'nie' : "$_->[1]min" )
                .   "/$_->[2])"

              } @$list
            : 'Keine Benutzer angemeldet';
    },
    %Dqc::Msg::User::Options::Commands,
    %Dqc::Msg::User::Notes::Commands,
    %Dqc::Msg::User::Privmsgs::Commands,
    %Dqc::Msg::User::Code::Commands,
    %Dqc::Msg::User::Uploads::Commands,
    %Dqc::Msg::User::Quotes::Commands,
    help => sub {
        return << 'EOHELP';
Benutzerhilfe:
  /me text: Von sich in der dritten Person reden
  /userlist: Die Liste der aktuell angemeldeten Benutzer anzeigen
  /set_refresh #: Ändert das Refresh-Intervall in Minuten
  /set_pw oldpassword password password: Ändert das Benutzerpasswort
  /set_theme themename: Aussehen ändern
  /set_status status: Benutzerstatus setzen
  /add_note notetext: Notizen hinzufügen
  /del_note #: Notiz entferen, # ist die Id der Notiz
  /del_file #: Upload entferen, # ist die Id der Datei
  /msg to nachricht: Private Nachricht "nachricht" an "to" schicken
  /add_code Textdata: Neuen Codeschnippsel erstellen
  /del_code #: Vorhandenen Codeschnippsel löschen
  /code # Textdate: Vorhandenen Codeschnippsel ändern
  /add_quote quotetext: Zitat in die Datenbank eintragen
  /quote suchwort: zufälliges Zitat mit Suchwort-Suche anzeigen
  /quote: Ein Zufälliges Zitat anzeigen
  /last_quote: Das letzte hinzugefügte Zitat anzeigen
  /last_quote #: Das #.letzte hinzugefügte Zitat anzeigen
  /code #: Vorhandenen Codeschnippsel anzeigen
  /help_admin: Befehle für Administratoren
EOHELP
    },
    help_admin => sub { die 'Sie sind kein Administrator' },
);

1;

