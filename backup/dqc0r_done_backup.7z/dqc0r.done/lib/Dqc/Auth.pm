package Dqc::Auth;
use Mojo::Base 'Mojolicious::Controller';
use Dqc;
use Dqc::Msg;

sub login {
    my $c = shift;
    my $s = $c->session;
    my $r = Dqc::dbh()->selectall_arrayref(
        'SELECT ben_name, ben_admin, ben_refresh, ben_theme, ben_status FROM ben_benutzer WHERE lower(ben_name)=lower(?) AND ben_passwort=?', 
        undef, $c->param('username'), Dqc::password($c->param('password'))
    );
    if ( @$r ) {
        @{ $s }{qw(user admin refresh theme status)} = @{ $r->[0] };
        $s->{theme} ||= 'Default';
        Dqc::Msg::add_msginfo(qq(Benutzer "$s->{user}" ist jetzt angemeldet));
        if ( $c->param('mobile') ) {
            $c->redirect_to('mobile');
        }
        else {
            $c->redirect_to('desktop');
        }
    }
    else {
        $c->stash(info => 'Anmelden fehlgeschlagen, bitte neu anmelden');
        $c->render('loginform');
    }
}

sub logout {
    my $c = shift;
    my $s = $c->session;
    my $u = $s->{user};
    Dqc::Msg::add_msginfo(qq(Benutzer "$u" ist jetzt abgemeldet));
    my $r = Dqc::dbh()->do(
        'UPDATE ben_benutzer SET ben_lastseen=0 WHERE ben_name=?',
        undef, $u
    );
    delete $s->{$_} for keys %$s;
    $c->stash(info => 'Abmelden erfolgreich, bitte neu anmelden');
    $c->render('loginform');
}

sub check {
    my $c = shift;
    my $s = $c->session();
    if ( $s->{user} ) {
        my $r = Dqc::dbh()->selectall_arrayref(
            'SELECT ben_admin, ben_refresh, ben_theme, ben_status FROM ben_benutzer WHERE lower(ben_name)=lower(?)',
            undef, $s->{user});
        if ( @$r ) {
            @{ $s }{qw(admin refresh theme status)} = @{ $r->[0] };
            $s->{theme} ||= 'Default';
        }
        $c->session(expiration => 60 * 60 * 24 * 14); # session shall last two weeks
        return 1;
    }
    else {
        $c->stash(info => 'Anmeldung ungültig, bitte neu anmelden');
        $c->render('loginform');
        return 0;
    }
}

sub check_password {
    my ( $u, $p ) = @_;
    my $r = Dqc::dbh()->selectall_arrayref(
        'SELECT COUNT(ben_id) FROM ben_benutzer WHERE lower(ben_name)=lower(?) AND ben_passwort=?', 
        undef, $u, Dqc::password($p)
    )->[0]->[0];
    return $r ? 1 : 0;
}

sub set_password {
    my $u = shift;
    my $p = shift;
    Dqc::dbh()->do(
        'UPDATE ben_benutzer SET ben_passwort=? WHERE lower(ben_name)=lower(?)',
        undef, Dqc::password($p), $u
    );
}

sub set_admin {
    my $u = shift;
    my $p = shift() ? 1 : 0;
    Dqc::dbh()->do(
        'UPDATE ben_benutzer SET ben_admin=? WHERE lower(ben_name)=lower(?)',
        undef, $p, $u
    );
}

sub add_user {
    my $u = shift;
    my $p = shift;
    Dqc::dbh()->do(
        'INSERT INTO ben_benutzer (ben_name, ben_passwort) VALUES (?,?)',
        undef, $u, Dqc::password($p)
    );
}

1;
