timeout = 0;
interval_default = 60;
interval = interval_default; // sekunden
history_list = new Array();
history_orig = new Array();
history_pointer = 0;
newmsgscount = 0;
newprivscount = 0;
hasfocus = 1;
chatactive = 0;
privatesdialog = 0;
usernames = new Array();

function set_interval(x) { 
    interval = x * 60; 
}

function start_timeout() { 
    if (interval < 16 * 60) 
        timeout = setTimeout(refresh, interval * 1000); 
    return('timeout started');
}

function cancel_timeout() { 
    if (interval < 16 * 60) 
        clearTimeout(timeout); 
    return('timeout canceled');
}

function disable_chat() {
    cancel_timeout();
    $('#refresh').attr('disabled', 'disabled');
    chatactive=0;
    return('chat disabled');
}

function enable_chat() {
    if (interval > 0) $('#refresh').removeAttr('disabled');
    start_timeout();
    chatactive=1;
    return('chat enabled');
}

function set_title() {
    document.title = '['+newmsgscount+'/'+newprivscount+'] '+titlestr;
}

function update(data) {
    var me    = data[0];
    var users = data[1];
    var msgs  = data[2];

    // Chat messages
    if ( hasfocus == 0 && msgs )
        newmsgscount = newmsgscount + msgs.length;

    // Buddy List
    if ( ! mobile ) {
        $('#userlist').empty();
        usernames = new Array();
        if ( users )
          $.map(users, function(val, i) {
            usernames.push(val[0]);
            var str = val[0];
            var cls = '';
            var hvr = '';
            var onc = '';

            if (val[4]) {
                cls = ' '+val[4];
                hvr = val[4];
            }
            else hvr = 'Online';
            if (val[4] == 'busy')       hvr = 'Beschäftigt';
            if (val[4] == 'lunch')      hvr = 'Mittagspause';
            if (val[4] == 'away')       hvr = 'Ausgeritten';
            if (val[4] == 'meeting')    hvr = 'Besprechung';
            if (val[4] == 'sleep')      hvr = 'Büroschlaf';
            if (val[4] == 'feierabend') hvr = 'Feierabend';
            if (val[4] == 'hidden')     hvr = 'Versteckt';

            if ( val[1] > 1440 )
                str = str+' (nie'
            else
                str = str+' ('+val[1]+'min';

            str = str+'/'+val[2]+')</p>';

            if ( val[3] == 1 )
                str = '@'+str;

            if ( val[0] == me[0] ) {
                str = '» '+str;
                $('#refresh_interval').val(val[1]);
                set_interval(val[1]);
                $('#status_change').val(val[4]);
            }
            else {
                onc = ' onclick="open_privmsg_to(\''+val[0]+'\')"';
                cls = cls + ' clickable';
            }
            $('#userlist').append('<p class="username'+cls+'" title="'+hvr+'"'+onc+'>'+str);
        });
    }

    // Messages
    if ( msgs )
      $.map(msgs, function(val, i) {
        var str = '<span class="time">('+val[0]+')</span> ';
        if ( val[1] )
            str = str+'<span class="username">'+val[1]+':</span>';

        str = str+' '+textfilter(val[2]);

        if ( val[1] ) 
            if ( val[1] == me[0] )
                $('#log').append('<p class="ownmsg">'+str+'</p>')
            else
                if ( val[2].toLowerCase().match(me[0].toLowerCase()) )
                    $('#log').append('<p class="markme">'+str+'</p>')
                else 
                    $('#log').append('<p>'+str+'</p>')
        else 
            $('#log').append('<p class="info">'+str+'</p>');
    });

    $("#log").each( function(){
        var scrollHeight = Math.max(this.scrollHeight, this.clientHeight);
        this.scrollTop = scrollHeight - this.clientHeight;
    });

    if ( ! mobile ) {
        $('#notescount').text(me[2]);
        $('#charcounter').text(me[4]);
        $('#codecount').text(me[5]);
        $('#uploadcount').text(me[6]);
    }
    
    if ( ! mobile ) {
        if ( me[3] )
            newprivscount = me[3]
        else
            newprivscount = 0;

        if ( me[3] > 0 ) {
            if ( privatesdialog == 1 ) {
                $('#privatescount').text('0');
                get_privates();
            }
            else {
                $('#privatescount').html('<span class="markprivs">'+me[3]+'</span>')
            }
        }
        else 
            $('#privatescount').text('0')
    }

    if ( ! mobile ) {
        var stylesheet = themeurl+me[1]+'/style.css';
        if ($("link[rel=stylesheet]").attr("href") != stylesheet)
            $("link[rel=stylesheet]").attr({href : stylesheet});
    }

    set_title();
    enable_chat();
    return('update done');
}

function refresh() {
    disable_chat();
    if ( hasfocus == 1 )
        $.getJSON(urlbase+'/refresh', update)
    else
        $.getJSON(urlbase+'/refresh_nofocus', update);
    return('refresh done');
}

function ajax_call(str) {
    if ( str != 'ok') 
        $('#log').append('<p class="info">'+str+'</p>');
    refresh();
    return('ajax call done');
}

function ajax_send_with_fun(msg, fun) {
    disable_chat();
    $.post( urlbase+'/msg', { "data": msg }, fun)
     .error(function(a,b,c){alert(c)});
    return('ajax request sent');
}

function ajax_send(msg) {
    disable_chat();
    $.post( urlbase+'/msg', { "data": msg }, ajax_call)
     .error(function(a,b,c){alert(c)});
    return('ajax request sent');
}

function send() {
    var msg = $('#msg').val();
    if ( msg ) {
        $('#msg').val('');
        history_orig.push(msg);
        history_pointer = history_orig.length;
        history_list = history_orig.slice()
        return(ajax_send(msg));
    }
}

function handle_event_keydown(e) {
    if ( e.keyCode == 13 && !e.shiftKey && !e.ctrlKey && !e.altKey)
        send();

    if ( e.shiftKey && e.keyCode == 38 && history_pointer > 0 ) { // shift + up arrow, history back
        var msg = $('#msg');
        var msgval = msg.val();
        if ( msgval.length > 0 && history_list[history_pointer] != msgval ) {
            history_list[history_pointer] = msgval;
        }
        history_pointer--;
        msg.val(history_list[history_pointer]);
    }
    if ( e.shiftKey && e.keyCode == 40 && history_pointer < history_list.length ) { // shift + down arrow, history foreward
        var msg = $('#msg');
        var msgval = msg.val();
        if ( msgval.length > 0 && history_list[history_pointer] != msgval ) {
            history_list[history_pointer] = msgval;
        }
        history_pointer++;
        if ( history_pointer < history_list.length ) {
            msg.val(history_list[history_pointer]);
        }
        else {
            msg.val('');
        }
    }
}

function handle_event_keyup(e) {
    if ( e.keyCode == 13 && !e.shiftKey && !e.ctrlKey && !e.altKey)
        $('#msg').val('');
}

function ins(str) {
    var msgstr = $('#msg').val();
    if (msgstr.length > 0 && msgstr.match(/\S$/))
        msgstr += ' ';
    $('#msg').val(msgstr+str);
}

function clrscr() {
    $('#log').empty();
}

function show_help() {
    ajax_send('/help');
}
function show_userlist() {
    ajax_send('/userlist');
}


function get_focus(e) {
    if( e.target === window && chatactive == 1 ) {
        hasfocus = 1;
        newmsgscount = 0;
        set_title();
        refresh();
        $('#msg').focus();
    }
}
function lose_focus(e) {
    if( e.target === window ) hasfocus = 0;
}

function get_notes() {
    $.get( urlbase+'/notes', print_notes)
     .error(function(a,b,c){alert(c)});
}
function print_notes(notes) {
    $('#noteslist').empty();
    if ( notes ) {
        $.map(notes, function(val, i) {
            var str = '<hr /><p class="note">';
            str += '<button class="delete_note" onClick="del_note('+val[0]+')">x</button>';
            str += '('+val[1]+') <b>'+val[2]+'</b>:<br />'+val[3]+'</p>'
            $('#noteslist').append(str);
        });
    }
    refresh();
}

function get_privates_wo() { $.get( urlbase+'/privat', print_privates_wo).error(function(a,b,c){alert(c)}) }
function get_privates_wu() { $.get( urlbase+'/privat', print_privates_wu).error(function(a,b,c){alert(c)}) }
function print_privates_wo(privs) { print_privates(privs,0) }
function print_privates_wu(privs) { print_privates(privs,1) }
function print_privates(privs, wu) {
    if ( privs ) {
        var me = privs.shift();
        $.map(privs, function(val, i) {
            var to = val[1];
            if ( val[1] == me ) to = val[2];
            var str = '<p class="privmsg clickable" onclick="select_privmsg_to(\''+to+'\')">('+val[0]+') <b>'+val[1]+' » '+val[2]+'</b>: '+val[3]+'</p>'
            $('#privmsgslog').prepend(str);
        });
        if ( wu && privs[0] ) $('#privusername').val(privs[0][1]);
    }
    refresh();
}

function get_filelist() {
    if ( $('#files').css('display') != 'none' )
        $.get( urlbase+'/filelist', print_filelist)
         .error(function(a,b,c){alert(c)});
}
function print_filelist(dat) {
    $('#filelist').empty();
    $.map(dat, function(val,i){
        var str = '<hr /><p class="note">';
        str += '<button class="delete_upload" onClick="del_upload('+val[0]+')">x</button>';
        str += '<a href="'+urlbase+'/file/'+val[0]+'">'+val[1]+'</a>';
        $('#filelist').append(str);
    });
    refresh();
    return 'file list generated';
}

function get_codelist() {
    $.get( urlbase+'/codelist', print_codelist)
     .error(function(a,b,c){alert(c)});
}

function print_codelist(dat) {
    $('#codelist').empty();
    $('#codelist').append('<option value="">Neuer Eintrag</option>');
    $.map(dat, function(val,i){
        var str = '<option value="'+val[0]+'"';
        if ( i == 0 ) {
            str = str + ' selected="selected"';
            get_code(val[0]);
        }
        str = str + '>'+val[1]+'</option>';
        $('#codelist').append(str);
    });
    refresh();
}

function get_code(id) {
    $('#codetext').val('');
    if ( !id ) {
        return 'no code selected → new code assumed';
    }
    $.get(urlbase+'/codetext/'+id, function(dat){
        $('#codetext').val(dat);
    });
}

